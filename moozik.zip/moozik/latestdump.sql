CREATE DATABASE  IF NOT EXISTS `musicdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `musicdb`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: musicdb
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bandgenres`
--

DROP TABLE IF EXISTS `bandgenres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandgenres` (
  `band_id` int(11) NOT NULL DEFAULT '0',
  `genre_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`band_id`,`genre_id`),
  KEY `genre_id` (`genre_id`),
  CONSTRAINT `bandgenres_ibfk_1` FOREIGN KEY (`band_id`) REFERENCES `bands` (`band_id`),
  CONSTRAINT `bandgenres_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandgenres`
--

LOCK TABLES `bandgenres` WRITE;
/*!40000 ALTER TABLE `bandgenres` DISABLE KEYS */;
INSERT INTO `bandgenres` VALUES (2008,30001),(2008,30002),(2008,30003),(2008,30004),(2008,30009),(2009,30009),(2008,30010),(2009,30010),(2008,30011),(2009,30011),(2008,30012),(2009,30012),(2002,30026),(2005,30026),(2001,30027),(2002,30028),(2003,30028),(2004,30029),(2004,30030);
/*!40000 ALTER TABLE `bandgenres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bandmembers`
--

DROP TABLE IF EXISTS `bandmembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandmembers` (
  `band_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `inband_position` varchar(80) DEFAULT 'band member',
  `band_joinedon` date DEFAULT NULL,
  `band_unjoined` date DEFAULT NULL,
  KEY `band_id` (`band_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `bandmembers_ibfk_1` FOREIGN KEY (`band_id`) REFERENCES `bands` (`band_id`),
  CONSTRAINT `bandmembers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandmembers`
--

LOCK TABLES `bandmembers` WRITE;
/*!40000 ALTER TABLE `bandmembers` DISABLE KEYS */;
INSERT INTO `bandmembers` VALUES (2002,107,'band member','1986-12-11',NULL),(2005,103,'band member',NULL,NULL),(2005,102,'band member',NULL,NULL),(2005,104,'band manager',NULL,NULL),(2005,109,'band member',NULL,NULL),(2005,105,'band manager',NULL,NULL),(2001,103,'band member',NULL,NULL),(2003,103,'band manager',NULL,NULL),(2003,102,'band member',NULL,NULL),(2003,106,'band member',NULL,NULL),(2003,108,'band manager',NULL,NULL),(2001,102,'band member',NULL,NULL),(2001,104,'band member',NULL,NULL);
/*!40000 ALTER TABLE `bandmembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bands`
--

DROP TABLE IF EXISTS `bands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bands` (
  `band_id` int(11) NOT NULL AUTO_INCREMENT,
  `band_name` varchar(80) NOT NULL,
  `band_website` varchar(80) DEFAULT NULL,
  `band_members` int(11) DEFAULT NULL,
  `band_ftime` datetime DEFAULT NULL,
  `band_atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `band_user_name` varchar(80) DEFAULT NULL,
  `band_user_password` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`band_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2018 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bands`
--

LOCK TABLES `bands` WRITE;
/*!40000 ALTER TABLE `bands` DISABLE KEYS */;
INSERT INTO `bands` VALUES (2001,'Megadeth','www.megadeth.com',4,'1983-03-16 00:00:00','2014-11-21 06:55:50','megadeth','megadeth'),(2002,'Iron Maiden','www.ironmaiden.com',6,'1975-06-01 00:00:00','2014-11-21 06:55:50','ironmaiden','ironmaiden'),(2003,'The Doors','www.thedoors.com',4,'1965-04-12 00:00:00','2014-11-21 06:55:50','thedoors','thedoors'),(2004,'Linkin Park','www.linkinpark.com',6,'1996-01-01 00:00:00','2014-11-21 06:55:50','linkinpark','linkinpark'),(2005,'AC/DC','www.acdc.com',5,'1973-01-01 00:00:00','2014-11-21 06:55:50','acdc','acdc'),(2006,'Parikrama','www.parikrama.com',4,'2001-06-19 00:00:00','2014-12-04 02:41:30','parikrama','parikrama'),(2007,'Madrasrock','www.madrasrock.com',7,'2008-08-08 00:00:00','2014-12-04 04:38:38','madrasrock','madrasrock'),(2008,'MidivalPunditz','www.MidivalPunditz.com',5,'2004-12-01 00:00:00','2014-12-04 05:03:32','midivalpunditz','midivalpunditz'),(2009,'Aerosmith','www.aerosmith.com',4,'1978-06-06 00:00:00','2014-12-04 05:09:47','aerosmith','aerosmith'),(2010,'poetsofthefall','www.poetsofthefall.com',5,'1975-06-03 00:00:00','2014-12-08 00:33:47','poetsofthefall','poetsofthefall');
/*!40000 ALTER TABLE `bands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar`
--

DROP TABLE IF EXISTS `calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar` (
  `user_id` varchar(80) DEFAULT NULL,
  `concert_id` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar`
--

LOCK TABLES `calendar` WRITE;
/*!40000 ALTER TABLE `calendar` DISABLE KEYS */;
INSERT INTO `calendar` VALUES ('102','5000001'),('102','5000013'),('103','5000014'),('103','5000016'),('103','5000001'),('103','5000017'),('103','5000004'),('103','5000010');
/*!40000 ALTER TABLE `calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concertgenres`
--

DROP TABLE IF EXISTS `concertgenres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `concertgenres` (
  `concert_id` int(11) DEFAULT NULL,
  `genre_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concertgenres`
--

LOCK TABLES `concertgenres` WRITE;
/*!40000 ALTER TABLE `concertgenres` DISABLE KEYS */;
INSERT INTO `concertgenres` VALUES (5000003,30017),(5000004,30017),(5000005,30017),(5000006,30017),(5000017,30002),(5000018,30025),(5000018,30026),(5000018,30027),(5000019,30002),(5000019,30004),(5000020,30002),(5000021,30025),(5000021,30026),(5000021,30027),(5000021,30028);
/*!40000 ALTER TABLE `concertgenres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concerts`
--

DROP TABLE IF EXISTS `concerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `concerts` (
  `concert_id` int(11) NOT NULL AUTO_INCREMENT,
  `concert_name` varchar(80) DEFAULT NULL,
  `concert_sdate` date DEFAULT NULL,
  `concert_stime` time DEFAULT NULL,
  `concert_edate` date DEFAULT NULL,
  `concert_etime` time DEFAULT NULL,
  `concert_lid` int(11) DEFAULT NULL,
  `concert_capacity` int(11) DEFAULT NULL,
  `concert_tcost` float DEFAULT NULL,
  `concert_description` longtext,
  `concert_atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`concert_id`),
  KEY `concert_lid` (`concert_lid`),
  CONSTRAINT `concerts_ibfk_1` FOREIGN KEY (`concert_lid`) REFERENCES `locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5000022 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concerts`
--

LOCK TABLES `concerts` WRITE;
/*!40000 ALTER TABLE `concerts` DISABLE KEYS */;
INSERT INTO `concerts` VALUES (5000001,'Prism','2014-12-26','05:00:00','2014-12-26','11:59:00',5020983,7500,500,'Charity Concert for Tsunami Floods','2014-11-21 07:53:47'),(5000002,'Peace','2015-01-11','12:00:00','2015-01-13','05:00:00',400005,15000,1500,'Celebrity Meet','2014-11-21 07:53:47'),(5000003,'Suave','2015-02-16','04:00:00','2015-02-16','09:00:00',400003,8000,750,'New Year Celebrations','2014-11-21 07:53:47'),(5000004,'Death Bed','2014-11-29','04:00:00','2014-11-29','09:30:00',400004,12000,1000,'World Tour','2014-11-21 07:53:47'),(5000005,'Chromzome','2014-12-06','07:00:00','2014-12-06','05:00:00',400002,2500,2500,'War of the Bands','2014-11-21 07:53:47'),(5000006,'Rock On','2014-10-06','07:00:00','2014-10-06','05:00:00',400002,15000,2500,'Rock Bands concert','2014-11-24 04:57:28'),(5000008,'U2 360','2015-01-01','07:00:00','2015-01-01','07:00:00',4943313,25000,500,'U2','2014-12-06 12:22:03'),(5000009,'A Bigger Bang Tour','2015-01-29','07:15:00','2015-01-01','07:15:00',400005,50000,150,'The Rolling Stones','2014-12-06 12:22:36'),(5000010,'The Wall Live','2014-12-25','07:30:00','2014-12-17','07:30:00',400005,25000,350,'Roger Waters','2014-12-06 12:34:44'),(5000011,'Black Ice','2014-12-30','07:30:00','2014-12-16','07:30:00',400004,5000,200,'AC/DC','2014-12-06 12:35:49'),(5000012,'Vertigo Tour','2014-12-24','07:30:00','2014-12-17','07:30:00',5573670,5000,200,'U2','2014-12-06 12:37:36'),(5000013,'Eagles','2014-12-24','07:30:00','2014-12-17','07:30:00',5020983,1000,200,'Long Road Out of Eden Tour','2014-12-06 12:40:06'),(5000014,'Glass Spider','2014-12-16','07:30:00','2014-12-17','07:30:00',400005,500,150,'David Bowie','2014-12-06 12:42:46'),(5000015,'Steel Wheels','2014-12-24','07:30:00','2014-12-24','07:30:00',400004,350,150,'The Rolling Stones','2014-12-06 12:52:12'),(5000016,'Victory','2014-12-16','07:45:00','2014-12-24','07:45:00',400005,1250,200,'The Jacksons','2014-12-06 12:53:05'),(5000017,'Tomorrowland','2014-12-31','06:45:00','2014-12-31','06:45:00',400001,1000,150,'DJ Show','2014-12-07 11:57:31'),(5000018,'Rockmania','2014-12-30','17:45:00','2015-01-01','17:45:00',12570918,750,100,'Indian Rock Show','2014-12-07 22:57:39'),(5000019,'The Joshua Tree','2014-12-10','20:45:00','2014-12-24','20:45:00',12570918,600,150,'U2','2014-12-08 01:51:53'),(5000020,'High Streets','2014-12-25','04:00:00','2014-12-26','04:00:00',9391180,650,NULL,'','2014-12-08 09:05:17'),(5000021,'Rock till death','2014-12-08','05:30:00','2014-12-26','05:30:00',400005,1000,NULL,'','2014-12-08 10:40:46');
/*!40000 ALTER TABLE `concerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fanof`
--

DROP TABLE IF EXISTS `fanof`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fanof` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `band_id` int(11) NOT NULL DEFAULT '0',
  `become_fanon` date DEFAULT NULL,
  `not_any_more` date DEFAULT NULL,
  PRIMARY KEY (`user_id`,`band_id`),
  KEY `band_id` (`band_id`),
  CONSTRAINT `fanof_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fanof_ibfk_2` FOREIGN KEY (`band_id`) REFERENCES `bands` (`band_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fanof`
--

LOCK TABLES `fanof` WRITE;
/*!40000 ALTER TABLE `fanof` DISABLE KEYS */;
INSERT INTO `fanof` VALUES (102,2002,NULL,NULL),(102,2005,NULL,NULL),(103,2001,NULL,NULL),(103,2009,NULL,NULL);
/*!40000 ALTER TABLE `fanof` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `follows` (
  `following_uid` int(11) NOT NULL,
  `followed_uid` int(11) NOT NULL,
  `follow_date` date DEFAULT NULL,
  `unfollow_date` date DEFAULT NULL,
  PRIMARY KEY (`following_uid`,`followed_uid`),
  KEY `followed_uid` (`followed_uid`),
  CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`following_uid`) REFERENCES `users` (`user_id`),
  CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`followed_uid`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follows`
--

LOCK TABLES `follows` WRITE;
/*!40000 ALTER TABLE `follows` DISABLE KEYS */;
INSERT INTO `follows` VALUES (102,104,NULL,NULL),(102,105,NULL,NULL),(102,106,NULL,NULL),(103,102,NULL,NULL),(103,105,NULL,NULL);
/*!40000 ALTER TABLE `follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genres` (
  `genre_id` int(11) NOT NULL,
  `genre_name` varchar(80) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`genre_id`),
  UNIQUE KEY `genre_name` (`genre_name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `genres_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `genres` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES (30000,'Genre',NULL),(30001,'Country',30000),(30002,'Alternative country',30001),(30003,'Cowpunk',30001),(30004,'Blues country',30001),(30005,'Electronic',30000),(30006,'Drone music',30005),(30007,'Illbient',30005),(30008,'Isolationism',30005),(30009,'Folk',30000),(30010,'Contemporary folk',30009),(30011,'Celtic music',30009),(30012,'Indie folk',30009),(30013,'Hip hop',30000),(30014,'Bongo Flava',30013),(30015,'Chap hop',30013),(30016,'Country-rap',30013),(30017,'Jazz',30000),(30018,'Acid jazz',30017),(30019,'Bebop',30017),(30020,'Boogie-woogie',30017),(30021,'Pop',30000),(30022,'Arab pop',30021),(30023,'Baroque pop',30021),(30024,'Bubblegum pop',30021),(30025,'Rock',30000),(30026,'Hard rock',30025),(30027,'Heavy metal',30025),(30028,'Blues rock',30025),(30029,'Alternative rock',30025),(30030,'Nu Metal',30025);
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listgenres`
--

DROP TABLE IF EXISTS `listgenres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listgenres` (
  `list_id` int(11) DEFAULT NULL,
  `genre_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listgenres`
--

LOCK TABLES `listgenres` WRITE;
/*!40000 ALTER TABLE `listgenres` DISABLE KEYS */;
INSERT INTO `listgenres` VALUES (6000012,30001),(6000012,30002),(6000012,30003),(6000012,30004),(6000012,30005),(6000012,30006),(6000012,30007),(6000012,30008),(6000012,30009),(6000012,30010),(6000012,30011),(6000012,30012),(6000012,30013),(6000012,30014),(6000012,30015),(6000012,30016),(6000012,30017),(6000012,30018),(6000012,30019),(6000012,30020),(6000012,30021),(6000012,30022),(6000012,30023),(6000012,30024),(6000012,30025),(6000012,30026),(6000012,30027),(6000012,30028),(6000012,30029),(6000012,30030),(6000013,30001),(6000013,30002),(6000013,30003),(6000013,30004),(6000013,30005),(6000013,30006),(6000013,30007),(6000013,30008),(6000013,30009),(6000013,30010),(6000013,30011),(6000013,30012),(6000013,30013),(6000013,30014),(6000013,30015),(6000013,30016),(6000013,30017),(6000013,30018),(6000013,30019),(6000013,30020),(6000013,30021),(6000013,30022),(6000013,30023),(6000013,30024),(6000013,30025),(6000013,30026),(6000013,30027),(6000013,30028),(6000013,30029),(6000013,30030),(6000014,30009),(6000016,30027),(6000016,30028),(6000016,30029);
/*!40000 ALTER TABLE `listgenres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lists` (
  `list_id` int(11) NOT NULL DEFAULT '0',
  `concert_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`,`concert_id`),
  KEY `concert_id` (`concert_id`),
  CONSTRAINT `lists_ibfk_1` FOREIGN KEY (`list_id`) REFERENCES `recommendedlist` (`list_id`),
  CONSTRAINT `lists_ibfk_2` FOREIGN KEY (`concert_id`) REFERENCES `concerts` (`concert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lists`
--

LOCK TABLES `lists` WRITE;
/*!40000 ALTER TABLE `lists` DISABLE KEYS */;
INSERT INTO `lists` VALUES (6000001,5000001),(6000012,5000001),(6000014,5000001),(6000001,5000002),(6000012,5000002),(6000014,5000002),(6000001,5000003),(6000012,5000003),(6000013,5000003),(6000014,5000003),(6000012,5000004),(6000013,5000004),(6000012,5000005),(6000013,5000005),(6000012,5000006),(6000012,5000008),(6000016,5000015),(6000012,5000017),(6000013,5000017),(6000016,5000020);
/*!40000 ALTER TABLE `lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(80) DEFAULT NULL,
  `location_capacity` int(11) DEFAULT NULL,
  `location_street` varchar(80) DEFAULT NULL,
  `location_city` varchar(80) DEFAULT NULL,
  `location_state` varchar(80) DEFAULT NULL,
  `location_country` varchar(80) DEFAULT NULL,
  `location_zipcode` int(11) DEFAULT NULL,
  `location_type` varchar(80) DEFAULT NULL,
  `location_cperson` varchar(80) DEFAULT NULL,
  `location_pnumber` varchar(80) DEFAULT NULL,
  `location_latitude` float(10,6) DEFAULT NULL,
  `location_longitude` float(10,6) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12570919 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (400001,'National Law College',15000,'13th Street','Bengaluru','Karnataka','India',500062,'Gardens','Mohit Das','9160540547',52.299450,13.624439),(400002,'Hard Rock Cafe',6000,'James Street','Hyderabad','Andhra Pradesh','India',500039,'Bar','Ram Kumar','8142439591',53.770950,12.575357),(400003,'Central Park',6000,'Union Square','New York City','New York','United States',11632,'Park','Johnson Brend','3476237956',53.822819,12.790551),(400004,'Chicago Central',15000,'Brimgham Street','Illinois','Chicago','United States',11987,'Gardens','Ashton Kutcher','3265684526',52.531048,12.338418),(400005,'Star Park',115000,'Butcher Street','London','London','UK',11569,'Stadium','Sherlock Holmes','2156254895',52.823437,12.073334),(4943313,'Motor City',8000,'127 Ludlow','New York','New York','United States',11416,'Bar','Victoria','3143471596',52.401646,13.264453),(5020983,'Pan Africa Market',7500,'1521 1st Ave','Seattle','Washington, WA','United States',25685,'Gardens','Evan','2659751569',35.929672,-78.948235),(5573670,'DROM',15000,'85 Avenue A (between 5th and 6th)','Syracuse','New York','United States',11562,'AmphiTheatre','Joshua Albert','3145689426',38.889511,-77.031998),(8888713,'Continental',25000,'25 Third Avenue','New York','New York','United States',11023,'Bar','Joey Machelloni','6697591425',38.032120,-78.477509),(9391180,'Barney McNabbs',7500,'600 Tuckahoe Avenue','Yonkers','Kansas','United States',32659,'AmphiTheatre','Ted Mosby','4451245784',36.379452,-75.830292),(11978919,'Community Church of New York',1500,'40 East 35th Street','New York','New York','United States',11410,'AmphiTheatre','Monica Belluci','3143470959',35.492599,-77.031998),(12570918,'Anyway Cafe',1500,'3234 E 2Nd Street','New York','New York','United States',7306,'Gardens','Jody West','3144568135',40.586540,-73.967499);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performing`
--

DROP TABLE IF EXISTS `performing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `performing` (
  `concert_id` int(11) DEFAULT NULL,
  `band_id` int(11) DEFAULT NULL,
  KEY `concert_id` (`concert_id`),
  KEY `band_id` (`band_id`),
  CONSTRAINT `performing_ibfk_1` FOREIGN KEY (`concert_id`) REFERENCES `concerts` (`concert_id`),
  CONSTRAINT `performing_ibfk_2` FOREIGN KEY (`band_id`) REFERENCES `bands` (`band_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performing`
--

LOCK TABLES `performing` WRITE;
/*!40000 ALTER TABLE `performing` DISABLE KEYS */;
INSERT INTO `performing` VALUES (5000001,2002),(5000002,2004),(5000003,2001),(5000004,2003),(5000005,2005),(5000005,2008),(5000014,2001),(5000014,2003),(5000015,2001),(5000015,2004),(5000016,2001),(5000016,2003),(5000017,2002),(5000018,2001),(5000018,2002),(5000018,2003),(5000019,2002),(5000019,2004),(5000020,2009),(5000021,2001),(5000021,2002),(5000021,2004);
/*!40000 ALTER TABLE `performing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plans` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `concert_id` int(11) NOT NULL DEFAULT '0',
  `plan` varchar(80) DEFAULT 'Not Defined',
  `rating` int(11) DEFAULT '-1',
  `user_review` longtext,
  `review_atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rated` varchar(80) DEFAULT 'no',
  `reviewed` varchar(80) DEFAULT 'no',
  `planned` varchar(80) DEFAULT 'no',
  PRIMARY KEY (`user_id`,`concert_id`),
  KEY `concert_id` (`concert_id`),
  CONSTRAINT `plans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `plans_ibfk_2` FOREIGN KEY (`concert_id`) REFERENCES `concerts` (`concert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (102,5000001,'Yes',4,'Mind Blowing performance! Literally out of the world !','2014-12-05 19:49:30','yes','yes','yes'),(102,5000006,'Attended',4,'Amazing Expreience! I love the way Curt Kobain strums the guitars. ','2014-11-24 05:00:03','yes','yes','yes'),(102,5000013,'Not Defined',-1,'cannot wait to attend this concert !','2014-12-06 23:54:19','no','yes','no'),(102,5000017,'Not Defined',-1,'Awesome DJ Show!','2014-12-08 08:54:11','no','yes','no'),(103,5000001,'Yes',-1,'Great experience','2014-12-05 19:49:30','no','yes','yes'),(103,5000017,'Not Defined',-1,'Its gonna be awesome','2014-12-08 10:17:19','no','yes','no');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendedlist`
--

DROP TABLE IF EXISTS `recommendedlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recommendedlist` (
  `user_id` int(11) DEFAULT NULL,
  `list_id` int(11) NOT NULL AUTO_INCREMENT,
  `list_name` varchar(80) NOT NULL,
  `list_gid` int(11) DEFAULT NULL,
  `list_atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`list_id`),
  KEY `user_id` (`user_id`),
  KEY `list_gid` (`list_gid`),
  CONSTRAINT `recommendedlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `recommendedlist_ibfk_2` FOREIGN KEY (`list_gid`) REFERENCES `genres` (`genre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6000018 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendedlist`
--

LOCK TABLES `recommendedlist` WRITE;
/*!40000 ALTER TABLE `recommendedlist` DISABLE KEYS */;
INSERT INTO `recommendedlist` VALUES (102,6000001,'My Rock List',30025,'2014-11-21 08:34:19'),(106,6000012,'Dream List',NULL,'2014-12-07 19:10:25'),(105,6000013,'Autumn List',NULL,'2014-12-07 20:34:07'),(103,6000014,'Insane List',NULL,'2014-12-07 21:03:12'),(103,6000016,'Dream Rock !',NULL,'2014-12-08 09:12:40');
/*!40000 ALTER TABLE `recommendedlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `shop_id` int(11) DEFAULT NULL,
  `concert_id` int(11) DEFAULT NULL,
  KEY `shop_id` (`shop_id`),
  KEY `concert_id` (`concert_id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`shop_id`) REFERENCES `ticketshops` (`shop_id`),
  CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`concert_id`) REFERENCES `concerts` (`concert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (7000001,5000001),(7000001,5000002),(7000001,5000003),(7000002,5000002),(7000003,5000003),(7000004,5000004),(7000005,5000005),(7000002,5000016),(7000004,5000016),(7000003,5000017),(7000001,5000018),(7000003,5000019),(7000004,5000006),(7000005,5000008),(7000002,5000009),(7000001,5000010),(7000004,5000011),(7000005,5000012),(7000001,5000013),(7000001,5000014),(7000002,5000015),(7000003,5000016),(7000004,5000020),(7000002,5000021),(7000004,5000021);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketshops`
--

DROP TABLE IF EXISTS `ticketshops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketshops` (
  `shop_id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(80) DEFAULT NULL,
  `shop_street` varchar(80) DEFAULT NULL,
  `shop_city` varchar(80) DEFAULT NULL,
  `shop_state` varchar(80) DEFAULT NULL,
  `shop_country` varchar(80) DEFAULT NULL,
  `shop_zipcode` int(11) DEFAULT NULL,
  `shop_oname` varchar(80) DEFAULT NULL,
  `shop_pnumber` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7000006 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketshops`
--

LOCK TABLES `ticketshops` WRITE;
/*!40000 ALTER TABLE `ticketshops` DISABLE KEYS */;
INSERT INTO `ticketshops` VALUES (7000001,'New York Lottery','118 Street, Summit Avenue','New York city','New York','United States',11417,'SushmithRreddy','9011020081'),(7000002,'Super Deli Store ','14 union Street, washington square','New York city','New York','United States',11400,'Afroze khan','3472860977'),(7000003,'Best Buy Theatre','78 Street, Ozone Park','New York city','New York','United States',11416,'Daniel','9091123456'),(7000004,'Apollo Shows','23 Street, Mercer Street','Jersey city','New Jersey','United States',7306,'John Wingman','34377809090'),(7000005,'Hermonth Arts','484 90 Avenue ','Jersey city','New Jersey','United States',4306,'Mark Pinkman','3432256767');
/*!40000 ALTER TABLE `ticketshops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdetails` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(80) NOT NULL,
  `user_mname` varchar(80) DEFAULT NULL,
  `user_lname` varchar(80) NOT NULL,
  `user_dob` date DEFAULT NULL,
  `user_email` varchar(80) DEFAULT NULL,
  `user_street` varchar(80) DEFAULT NULL,
  `user_city` varchar(80) DEFAULT NULL,
  `user_state` varchar(80) DEFAULT NULL,
  `user_country` varchar(80) DEFAULT NULL,
  `user_zipcode` varchar(80) DEFAULT NULL,
  `user_gender` varchar(80) DEFAULT NULL,
  `user_image` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `userdetails_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdetails`
--

LOCK TABLES `userdetails` WRITE;
/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` VALUES (101,'Admin',NULL,'Admin','2014-11-20','payamrastogi@gmail.com','2 Metrotech, Jay Street, Brooklyn','New York City','New York','United States','10003','male',NULL),(102,'Payam',NULL,'Rastogi','1987-01-07','pr1228@nyu.edu','Apt No. 2L, Building No. 484, Mercer St.','Jersey City','New Jersey','United States','7306','male','upload/batman and the penguin.jpg'),(103,'Anirudh',NULL,'Srinivas','1990-04-13','anirudhsr@hotmail.com','9422, 78 Street, Ozone Park','New Yor City','New York','United States','11416','male','upload/NFS ProStreet 01.jpg'),(104,'Anupam',NULL,'Jain','1987-04-22','anupam2204.smart@gmail.com','52/77 VT road, mansarovar','Jaipur','Rajasthan','India','302020','male','upload/0505_092859.jpg'),(105,'Ankit',NULL,'Gupta','1987-03-09','gupta007ankit@gmail.com','60 Patel Marg, 22 Godown','Jaipur','Rajasthan','India','302016','male',NULL),(106,'Afroze',NULL,'Khan','1990-02-07','afroze.khan@gmail.com','9422 78th street','New York City',NULL,NULL,NULL,'male',NULL),(107,'Steve',NULL,'Harris','1987-03-09','steve.harris@gmail.com','9422, 78 Street, Ozone Park','New York',NULL,NULL,NULL,NULL,NULL),(108,'Fahad',NULL,'ahmed','1990-04-13','fahad91@nyu.edu','60 Patel Marg, 22 Godown','Jaipur',NULL,NULL,NULL,NULL,NULL),(109,'Arjun',NULL,'Singh','1987-01-07','arjun.si@hotmail.com','2 Metrotech, Jay Street, Brooklyn','New York City',NULL,NULL,NULL,NULL,NULL),(110,'Karan',NULL,'Kumar','2014-11-20','karan.karan@nyu.edu','60 Patel Marg, 22 Godown','Jaipur',NULL,NULL,NULL,NULL,NULL),(111,'Pranav',NULL,'Raj','1987-04-22','pranav.raj@wipro.com','2 Metrotech, Jay Street, Brooklyn','New York City',NULL,NULL,NULL,NULL,NULL),(112,'Malcolm',NULL,'Gladwell','1987-04-22','malcolmg@gmail.com','52/77 VT road, mansarovar','Ahmedabad',NULL,NULL,NULL,NULL,NULL),(113,'Gaurav',NULL,'Bansal','1990-05-09','gaurav.cool@gmail.com','60 Patel Marg, 22 Godown','Jaipur',NULL,NULL,NULL,NULL,NULL),(114,'Rahul',NULL,'Kumar','2014-12-08','rahul4017@gmail.com','Apt No. 2L, Building No. 484 M','Jesey city','New Jersey','United States','07306','male',NULL);
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergenres`
--

DROP TABLE IF EXISTS `usergenres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergenres` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `genre_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`genre_id`),
  KEY `genre_id` (`genre_id`),
  CONSTRAINT `usergenres_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `usergenres_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergenres`
--

LOCK TABLES `usergenres` WRITE;
/*!40000 ALTER TABLE `usergenres` DISABLE KEYS */;
INSERT INTO `usergenres` VALUES (102,30025),(103,30025),(102,30026),(103,30026),(104,30026),(102,30027),(105,30027),(102,30028),(103,30028),(103,30029);
/*!40000 ALTER TABLE `usergenres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(80) NOT NULL,
  `user_password` varchar(80) NOT NULL,
  `user_repo` int(11) DEFAULT '1',
  `user_ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_laccess` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_type` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (101,'admin','admin',19,'2014-11-20 22:21:32','2014-12-08 07:24:49','admin'),(102,'payamrastogi','payam123',19,'2014-11-20 22:21:32','2014-12-08 20:38:55','user'),(103,'anirudh','anirudh',18,'2014-11-20 22:21:32','2014-12-08 20:47:03','user'),(104,'anupamjain','anupamjain',13,'2014-11-21 01:20:05','2014-12-08 20:16:39','user'),(105,'ankitgupta','ankitgupta',14,'2014-11-21 01:20:06','2014-12-08 07:24:49','user'),(106,'afrozekhan','afrozekhan',8,'2014-11-24 02:24:45','2014-12-08 20:48:07','user'),(107,'steveharris','steveharris',10,'2014-11-24 02:24:45','2014-12-08 07:24:49','user'),(108,'fahad','fahad',3,'2014-12-03 20:45:27','2014-12-08 20:46:57','user'),(109,'arjun','arjun',6,'2014-12-03 20:45:47','2014-12-08 20:47:56','user'),(110,'karan','karan',6,'2014-12-03 20:54:06','2014-12-08 20:47:56','user'),(111,'pranav','pranav',15,'2014-12-03 20:55:01','2014-12-08 07:24:49','user'),(112,'malcolm','malcolm',12,'2014-12-07 19:27:23','2014-12-08 09:17:53','user'),(113,'gaurav','gaurav',9,'2014-12-07 20:58:20','2014-12-08 07:24:49','user'),(114,'rahul','rahul',7,'2014-12-07 21:00:52','2014-12-08 20:47:56','user');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_genre_category`
--

DROP TABLE IF EXISTS `view_genre_category`;
/*!50001 DROP VIEW IF EXISTS `view_genre_category`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_genre_category` (
  `level1` tinyint NOT NULL,
  `level2` tinyint NOT NULL,
  `level3` tinyint NOT NULL,
  `level4` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'musicdb'
--

--
-- Dumping routines for database 'musicdb'
--
/*!50003 DROP PROCEDURE IF EXISTS `delete_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_list`(IN p_list_id varchar(80), 
IN p_user_id varchar(80))
BEGIN
delete from lists where list_id = p_list_id;
delete from listgenres where list_id = p_list_id;
delete from recommendedlist where list_id = p_list_id and user_id=p_user_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_band_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_band_details`(IN p_band_name varchar(80),
IN p_band_user_name varchar(80),
IN p_band_user_password varchar(80),
IN p_band_website varchar(80),
IN p_band_members int(11),
OUT p_band_id int)
BEGIN
Insert into bands (band_name, band_user_name, band_user_password,band_website,band_members) values (p_band_name, p_band_user_name,p_band_user_password, p_band_website, p_band_members);
select last_insert_id() into p_band_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_concerts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_concerts`(IN p_concert_name varchar(80), 
IN p_concert_sdate date,
IN p_concert_stime time,
IN p_concert_edate date,
IN p_concert_etime time,
IN p_concert_lid int(11),
IN p_concert_capacity int(11),
IN p_concert_tcost float,
IN p_concert_description longtext,
IN p_user_id int,
OUT p_concert_id int)
BEGIN
Declare p_user_repo int;
Select user_repo into p_user_repo from users where user_id = p_user_id;
if p_user_repo > 10 then
	Insert into concerts (concert_name,concert_sdate,concert_stime,concert_edate,concert_etime,concert_lid,concert_tcost,concert_description) values (p_concert_name,p_concert_sdate,p_concert_stime,p_concert_edate,p_concert_etime,p_concert_lid,p_concert_capacity,concert_tcost,p_concert_description);
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_concerts_by_band` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_concerts_by_band`(IN p_concert_name varchar(80), 
IN p_concert_sdate date,
IN p_concert_stime time,
IN p_concert_edate date,
IN p_concert_etime time,
IN p_concert_lid int(11),
IN p_concert_tcost float,
IN p_concert_capacity int(11),
IN p_concert_description longtext,
OUT p_concert_id int)
BEGIN
Insert into concerts (concert_name,concert_sdate,concert_stime,concert_edate,concert_etime,concert_lid,concert_capacity,concert_tcost,concert_description) values (p_concert_name,p_concert_sdate,p_concert_stime,p_concert_edate,p_concert_etime,p_concert_lid,p_concert_capacity,concert_tcost,p_concert_description);
select last_insert_id() into p_concert_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_concerts_recommendedlist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_concerts_recommendedlist`(IN p_user_id int,
IN p_concert_id int,
IN p_list_name varchar(80),
IN p_list_gid int)
BEGIN
Declare p_list_id int;
select list_id into p_list_id from recommendedlist where list_name = p_list_name;
if p_list_id is not null then
	Insert into lists (list_id, concert_id) values (p_list_id, p_concert_id);
else
	Insert into recommendedlist (user_id, list_id, list_name, list_gid) values (p_user_id, p_list_id, p_list_name, p_list_gid);
	Select last_insert_id() into p_list_id;
	Insert into lists (list_id, concert_id) values (p_list_id, p_concert_id);
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_list`(IN p_list_name varchar(80), 
IN p_user_id varchar(80),
OUT p_list_id int)
BEGIN
Insert into recommendedlist (list_name,user_id) values (p_list_name, p_user_id);
select last_insert_id() into p_list_id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_user_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_user_details`(IN p_user_name varchar(80),
IN p_user_password varchar(80),
IN p_user_fname varchar(80),
IN p_user_lname varchar(80),
IN p_user_email varchar(80),
OUT p_user_id int)
BEGIN
Insert into users (user_name, user_password, user_repo) values (p_user_name,p_user_password, 1);
select last_insert_id() into p_user_id;
Insert into userdetails (user_id, user_fname, user_lname,user_email) values (p_user_id, p_user_fname, p_user_lname, p_user_email);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `view_genre_category`
--

/*!50001 DROP TABLE IF EXISTS `view_genre_category`*/;
/*!50001 DROP VIEW IF EXISTS `view_genre_category`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_genre_category` AS select `t1`.`genre_id` AS `level1`,`t2`.`genre_id` AS `level2`,`t3`.`genre_id` AS `level3`,`t4`.`genre_id` AS `level4` from (((`genres` `t1` left join `genres` `t2` on((`t2`.`parent_id` = `t1`.`genre_id`))) left join `genres` `t3` on((`t3`.`parent_id` = `t2`.`genre_id`))) left join `genres` `t4` on((`t4`.`parent_id` = `t3`.`genre_id`))) where (`t1`.`genre_name` = 'Genre') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-08 15:49:22
