<center>
    <style type="text/css">
        #footer
        {
            position: relative;
            top: 150px;
        }
    </style>
    <div id="footer">
      <div class="container">
        <p class="muted credit">
            Site Designed and Built By
            <a target="_blank" href="http://coddicted.com/about-us/">Payam Rastogi </a>
            With
            <a target="_blank" href="http://twitter.github.io/bootstrap">Bootstrap</a>
            and PHP.
            View the <a href="https://github.com/payamrastogi/social">GitHub</a> repo.
        </p>
      </div>
    </div>
</center>
