Design Documents:
	Go Over DB.pdf, ER.pdf gives you the overall view of the project.