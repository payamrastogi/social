<?php
$target_Path = "images/";
$target_Path = $target_Path.basename($_FILES['fileuploaded']['name'] );

move_uploaded_file( $_FILES['fileuploaded']['tmp_name'], $target_Path );
echo $target_Path;


?>
