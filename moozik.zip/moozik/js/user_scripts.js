$(document).on("click", ".changephoto", function(event){
event.preventDefault();
$("#pic_select").trigger("click");
});
$(document).on("change", "#pic_select", function(event){

$("#formchangephoto").trigger("submit");
});

$(document).on("submit", "#formchangephoto", function(event){
	event.preventDefault();
fd = new FormData()
fd.append("fileuploaded", $("#pic_select")[0].files[0]);	
$.ajax({
	url: "changephoto.php",
	type: "POST",
	data: fd,
	processData: false,
	contentType: false,
	success: function(response){
	$("#profile_pic_div").attr("src", response);
	}
	});
});
